package com.example.todolist.DTO

class ToDoItem{
    var id: Long = -1
    var todoId :Long = -1
    var itemName = ""
    var isCompleted = false
}